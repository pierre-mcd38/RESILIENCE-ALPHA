
    let t0Done = false;
    let lastAutoIncidentId = null;
    let userAskedCustom = false;
    let currentLockoutSecs = 0;
    let bioFaceVerified = false;

    const ATTACK_LABELS = {
      'NOMINAL': 'AUCUNE MENACE (TRAFIC NOMINAL)',
      'FLOOD_L7_VERIFY_BATCH': '🚨 FLOOD APPLICATIF L7 CRYPTO (/api/v1/transactions/verify-batch)',
      'BRUTE_FORCE_AUTH_JWT': '🚨 FORCE BRUTE AUTHENTIFICATION JWT (/auth/v1/token)',
      'INJECTION_L7_SQLI_XSS': '🚨 INJECTION CRITIQUE L7 (SQLi / XSS / Path Traversal)',
      'SATURATION_LATENCE_DOS': '🚨 SATURATION WORKERS & DÉGRADATION LATENCE P95'
    };

    async function executePayment(label) {
      const amountCents = label === 'T0' ? 5000 : 2500;
      const fb = document.getElementById('tx-feedback');
      fb.style.color = '#93c5fd';
      fb.textContent = `Exécution de la transaction ${label} (${(amountCents/100).toFixed(2)} EUR)...`;
      try {
        const res = await fetch('/live/v1/trigger-payment', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({label, amount_cents: amountCents})
        });
        const data = await res.json();
        if (res.ok) {
          fb.style.color = '#34d399';
          fb.textContent = `Transaction ${label} COMMITTED : ${data.transaction.transaction_id}`;
          if (label === 'T0') t0Done = true;
        } else {
          fb.style.color = '#f87171';
          fb.textContent = `Erreur : ${data.error || 'échec'}`;
        }
      } catch (e) {
        fb.style.color = '#f87171';
        fb.textContent = `Erreur réseau : ${e}`;
      }
      refreshState();
    }

    async function resetPlatform() {
      userAskedCustom = false;
      lastAutoIncidentId = null;
      await fetch('/live/v1/reset', {method: 'POST'});
      document.querySelectorAll('.step-box').forEach(el => el.classList.remove('done'));
      document.getElementById('tx-feedback').textContent = 'Plateforme réinitialisée (IP débloquées, état NORMAL).';
      refreshState();
    }

    async function triggerAttackVector(attackType) {
      userAskedCustom = false;
      const fb = document.getElementById('tx-feedback');
      fb.style.color = '#fbbf24';
      fb.textContent = `Lancement de l'attaque [${attackType}] vers la passerelle WAF : observation par l'IA en cours...`;
      await fetch('/live/v1/trigger-scenario', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          source_ip: '192.168.137.135',
          attack_type: attackType,
          duration_seconds: 10,
          rate_rps: 25
        })
      });
    }

    async function askOllama(questionText) {
      userAskedCustom = true;
      const box = document.getElementById('ollama-output');
      box.style.border = '2px solid #a855f7';
      box.style.background = '#1e1b4b';
      box.textContent = `⏳ GEMMA 4 (8.0B) EN COURS D'INFÉRENCE...\n\nOllama consulte le corpus documentaire confiné (docs/*.md) et génère la réponse en local sur votre machine...\n\nQuestion posée : "${questionText}"`;
      try {
        const res = await fetch('/live/v1/ai-ask', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({query: questionText})
        });
        const data = await res.json();
        box.style.border = '1px solid #10b981';
        box.style.background = '#091524';
        box.textContent = data.formatted_report || data.answer || 'Aucune réponse.';
      } catch (e) {
        box.style.border = '1px solid #ef4444';
        box.textContent = `Erreur lors de l'appel à Ollama : ${e}`;
      }
    }

    function askOllamaCustom() {
      const inp = document.getElementById('rag-question-input');
      const q = (inp.value || '').trim();
      if (!q) return;
      askOllama(q);
    }

    async function refreshState() {
      try {
        const res = await fetch('/live/v1/summary');
        const s = await res.json();

        const st = s.remediator.state;
        const badge = document.getElementById('state-badge');
        badge.textContent = 'ÉTAT : ' + st;
        badge.className = 'badge state-' + st;

        // Statut Ollama
        const ollamaBadge = document.getElementById('ollama-badge');
        if (s.ai_copilot && s.ai_copilot.llm_status === 'OLLAMA_ACTIVE') {
          ollamaBadge.textContent = `IA OLLAMA (${s.ai_copilot.model}) : ACTIF`;
          ollamaBadge.style.borderColor = '#10b981';
          ollamaBadge.style.color = '#6ee7b7';
        } else {
          ollamaBadge.textContent = 'IA RAG VECTORIEL : ACTIF';
        }

        // Radar IA IsolationForest
        const ml = s.detector;
        const feat = s.telemetry.features || {};
        document.getElementById('ai-inference-count').textContent = `${ml.inferences_total} fenêtres analysées | ${ml.anomalies_total} anomalies`;

        const activeAttack = (ml.last_is_anomaly ? ml.last_attack_type : (s.ai_copilot && s.ai_copilot.last_detected_attack_type)) || 'NOMINAL';
        const banner = document.getElementById('ai-attack-banner');
        const labelEl = document.getElementById('ai-attack-label');
        const scoreEl = document.getElementById('ai-score-pill');
        scoreEl.textContent = `Score ML: ${(ml.last_score || 0).toFixed(4)} (Seuil: -0.1176)`;

        if (ml.last_is_anomaly || st === 'SUSPECT' || st === 'INCIDENT' || st === 'REMEDIATING') {
          banner.className = 'attack-banner attack-alert';
          labelEl.textContent = ATTACK_LABELS[activeAttack] || `🚨 ATTAQUE DÉTECTÉE PAR L'IA : ${activeAttack}`;
        } else if (st === 'RECOVERED' && activeAttack !== 'NOMINAL') {
          banner.className = 'attack-banner attack-nominal';
          labelEl.textContent = `✅ MENACE NEUTRALISÉE PAR L'IA (${ATTACK_LABELS[activeAttack] || activeAttack})`;
        } else {
          banner.className = 'attack-banner attack-nominal';
          labelEl.textContent = ATTACK_LABELS['NOMINAL'];
        }

        document.getElementById('ml-consec').textContent = ml.consecutive_anomalies + ' / 2';
        document.getElementById('feat-rps').textContent = (feat.req_rate_rps || 0).toFixed(1) + ' req/s';
        document.getElementById('feat-lat').textContent = (feat.latency_p95_ms || 0).toFixed(1) + ' ms';
        document.getElementById('feat-sat').textContent = Math.round((feat.cpu_worker_saturation || 0) * 100) + '%';
        document.getElementById('feat-err').textContent = ((feat.error_rate_ratio || 0) * 100).toFixed(1) + '%';
        document.getElementById('feat-sig').textContent = (s.telemetry.waf_signature_hits || 0) + ' sig';
        document.getElementById('feat-auth').textContent = (s.telemetry.waf_auth_requests || 0) + ' auth';
        document.getElementById('feat-ip').textContent = s.telemetry.dominant_source_ip || '127.0.0.1';

        // Barres XAI (Top contributing features)
        const topFeats = (ml.last_event && ml.last_event.top_contributing_features) || [];
        const xaiBox = document.getElementById('xai-bars');
        if (topFeats.length > 0) {
          xaiBox.innerHTML = topFeats.map(f => {
            const pct = Math.min(100, Math.max(8, Math.round((f.z_score || 0.5) * 18)));
            return `<div class="feature-bar-row">
              <span class="mono" style="width:175px;color:#cbd5e1">${f.feature}</span>
              <div class="feature-bar-bg"><div class="feature-bar-fill" style="width:${pct}%"></div></div>
              <span class="mono" style="width:110px;text-align:right;color:#fca5a5">val=${f.value} (z=${f.z_score})</span>
            </div>`;
          }).join('');
        }

        // Compteurs par vecteur
        const byType = ml.anomalies_by_type || {};
        document.getElementById('cnt-vec-flood').textContent = byType['FLOOD_L7_VERIFY_BATCH'] || 0;
        document.getElementById('cnt-vec-auth').textContent = byType['BRUTE_FORCE_AUTH_JWT'] || 0;
        document.getElementById('cnt-vec-sqli').textContent = byType['INJECTION_L7_SQLI_XSS'] || 0;
        document.getElementById('cnt-vec-dos').textContent = byType['SATURATION_LATENCE_DOS'] || 0;

        // Diagnostic automatique Ollama au premier plan
        if (!userAskedCustom && s.ai_copilot && s.ai_copilot.live_diagnosis) {
          document.getElementById('ollama-output').textContent = s.ai_copilot.live_diagnosis;
        }

        // Comptes et transactions
        document.getElementById('inv-status').textContent =
          (s.ledger.total_cents / 100).toFixed(2) + ' EUR (' + (s.ledger.consistent ? 'INTÈGRE' : 'ERREUR') + ')';
        const accs = s.ledger.accounts || {};
        if (accs['ACC-FR-001']) document.getElementById('bal-1').textContent = (accs['ACC-FR-001'].balance_cents / 100).toFixed(2) + ' EUR';
        if (accs['ACC-FR-002']) document.getElementById('bal-2').textContent = (accs['ACC-FR-002'].balance_cents / 100).toFixed(2) + ' EUR';
        document.getElementById('tx-count').textContent = s.ledger.transactions.length;

        // WAF & Remediator
        document.getElementById('waf-profile').textContent = s.waf.rate_limit_profile;
        const blockedList = s.waf.active_blocked_ips || [];
        document.getElementById('waf-blocked-ips').textContent =
          blockedList.length ? blockedList.map(x => x.ip_address).join(', ') : 'Aucune';
        const totalBlocked = (s.waf.metrics.waf_blocked_dynamic_ip_total || 0) +
                             (s.waf.metrics.waf_blocked_ratelimit_total || 0) +
                             (s.waf.metrics.waf_blocked_signature_total || 0);
        document.getElementById('waf-blocked-hits').textContent = totalBlocked;

        const mttd = s.remediator.metrics.remediator_last_mttd_seconds || 0;
        const mttr = s.remediator.metrics.remediator_last_mttr_seconds || 0;
        document.getElementById('mttd-mttr').textContent =
          (mttd > 0 || mttr > 0) ? `MTTD=${mttd.toFixed(2)}s | MTTR=${mttr.toFixed(2)}s` : '—';

        const lastProbe = s.remediator.last_verified_transaction;
        document.getElementById('probe-tx').textContent =
          lastProbe ? `${lastProbe.transaction_id} (1,00 EUR COMMITTED)` : '—';

        // Chain steps
        const hasTx = s.ledger.transactions.length > 0;
        if (hasTx || t0Done) {
          document.getElementById('step-t0').classList.add('done');
          document.getElementById('step-t0-txt').textContent = 'PASS (' + s.ledger.transactions[0].transaction_id.slice(0, 12) + ')';
        }
        if ((feat.req_rate_rps || 0) > 4 || totalBlocked > 0 || blockedList.length > 0) {
          document.getElementById('step-t1').classList.add('done');
          document.getElementById('step-t1-txt').textContent = 'Reçue (' + (s.telemetry.dominant_source_ip || '2e PC') + ')';
        }
        if ((feat.latency_p95_ms || 0) > 50 || (feat.error_rate_ratio || 0) > 0.2 || blockedList.length > 0) {
          document.getElementById('step-t2').classList.add('done');
          document.getElementById('step-t2-txt').textContent = 'Observée';
        }
        if (ml.anomalies_total > 0 || blockedList.length > 0) {
          document.getElementById('step-t3').classList.add('done');
          document.getElementById('step-t3-txt').textContent = 'Détectée (' + activeAttack.slice(0, 14) + ')';
        }
        if (blockedList.length > 0) {
          document.getElementById('step-t4').classList.add('done');
          document.getElementById('step-t4-txt').textContent = 'IP ' + blockedList[0].ip_address + ' bannie';
        }
        if (st === 'RECOVERED' && lastProbe) {
          document.getElementById('step-t5').classList.add('done');
          document.getElementById('step-t5-txt').textContent = 'RECOVERED (' + lastProbe.transaction_id.slice(0, 12) + ')';
        }

        // Timeline
        const tlBox = document.getElementById('timeline-box');
        tlBox.innerHTML = (s.remediator.recent_timeline || []).slice().reverse().slice(0, 18).map(item =>
          `<div class="log-item"><span style="color:#60a5fa">[${item.timestamp.slice(11,19)}]</span> <strong>[${item.stage}]</strong> ${item.message}</div>`
        ).join('');

        // Transactions table
        const tbody = document.getElementById('tx-table');
        tbody.innerHTML = (s.ledger.transactions || []).slice(0, 8).map(tx =>
          `<tr>
            <td class="mono">${tx.transaction_id}</td>
            <td class="mono">${(tx.amount_cents/100).toFixed(2)} ${tx.currency}</td>
            <td class="mono">${tx.idempotency_key.slice(0, 18)}</td>
            <td style="color:#34d399;font-weight:700">${tx.status}</td>
          </tr>`
        ).join('');

        // Mise à jour de l'état biométrique et de l'ESP8266
        const bio = s.biometrics || {};
        if (bio.esp_hardware && !bioFaceVerified && currentLockoutSecs <= 0) {
          updateEspLedVisual(bio.esp_hardware.current_state, bio.esp_hardware.port);
        }
        const bioTbody = document.getElementById('bio-habilitations-table');
        if (bioTbody && bio.habilitations) {
          bioTbody.innerHTML = bio.habilitations.map(h => `
            <tr>
              <td><strong>${h.display_name}</strong></td>
              <td class="mono">${h.username}</td>
              <td>${h.role}</td>
              <td><span style="color:${h.is_locked ? '#f87171' : '#34d399'};font-weight:700">${h.is_locked ? 'BLOQUÉ (' + h.lockout_seconds_remaining + 's)' : h.status}</span></td>
              <td>${h.is_locked ? `<button class="amber" style="padding:2px 6px;font-size:0.7rem;margin:0;" onclick="resetOperatorLockout('${h.username}')">Débloquer</button>` : '—'}</td>
            </tr>
          `).join('');
        }
      } catch (e) {}
    }

    setInterval(() => {
      if (currentLockoutSecs > 0) {
        currentLockoutSecs--;
        document.getElementById('lockout-secs').textContent = currentLockoutSecs;
        if (currentLockoutSecs <= 0) {
          document.getElementById('lockout-countdown').style.display = 'none';
          document.getElementById('bio-cam-btn').disabled = false;
        }
      }
    }, 1000);

    function updateEspLedVisual(state, port) {
      const led = document.getElementById('virtual-esp-led');
      const title = document.getElementById('esp-led-title');
      const sub = document.getElementById('esp-led-sub');
      const badge = document.getElementById('esp-status-badge');
      if (port && badge) badge.textContent = `ESP-12F ${port}`;
      if (!led || !title || !sub) return;

      if (state === 'GREEN_BLINK') {
        led.style.background = '#10b981';
        led.style.boxShadow = '0 0 16px #10b981';
        title.textContent = 'LED Bicolore : VERT CLIGNOTANT';
        sub.textContent = '🟢 Visage reconnu par IA — Saisissez votre mot de passe';
      } else if (state === 'GREEN_SOLID_30S') {
        led.style.background = '#10b981';
        led.style.boxShadow = '0 0 18px #10b981';
        title.textContent = 'LED Bicolore : VERT FIXE (30s)';
        sub.textContent = '🟢 Mot de passe validé — Accès Back-office ouvert';
      } else if (state === 'RED_SOLID_30S') {
        led.style.background = '#ef4444';
        led.style.boxShadow = '0 0 18px #ef4444';
        title.textContent = 'LED Bicolore : ROUGE FIXE (30s)';
        sub.textContent = '🔴 Visage non reconnu / Compte bloqué';
      } else if (state === 'RED_BLINK_10X') {
        led.style.background = '#ef4444';
        led.style.boxShadow = '0 0 16px #ef4444';
        title.textContent = 'LED Bicolore : ROUGE CLIGNOTANT (10x)';
        sub.textContent = '🔴 Mot de passe erroné — Cycle réinitialisé';
      } else {
        led.style.background = '#475569';
        led.style.boxShadow = 'none';
        title.textContent = 'LED Bicolore : ÉTEINTE (OFF)';
        sub.textContent = '⚪ ESP-12F en attente d\'identification';
      }
    }

    // Flux vidéo de la caméra intégrée du PC portable
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 640 }, height: { ideal: 480 } } })
        .then(stream => {
          const vid = document.getElementById('laptop-cam-video');
          if (vid) vid.srcObject = stream;
        })
        .catch(err => {
          console.warn("Accès vidéo navigateur (fallback backend actif) :", err);
        });
    }

    function captureLaptopVideoFrame() {
      const vid = document.getElementById('laptop-cam-video');
      const cvs = document.getElementById('laptop-cam-canvas');
      if (vid && vid.videoWidth > 0 && cvs) {
        cvs.width = vid.videoWidth;
        cvs.height = vid.videoHeight;
        const ctx = cvs.getContext('2d');
        ctx.drawImage(vid, 0, 0, cvs.width, cvs.height);
        return cvs.toDataURL('image/jpeg', 0.9);
      }
      return null;
    }

    async function enrollMyFaceSnapshot() {
      const username = document.getElementById('bio-username-input').value.trim() || 'operator_alpha';
      const fb = document.getElementById('bio-feedback-msg');
      fb.textContent = "📸 Capture de votre visage depuis la caméra intégrée en cours...";
      fb.style.color = "#38bdf8";

      const b64 = captureLaptopVideoFrame();
      try {
        const res = await fetch('/live/v1/bio-enroll', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            username: username,
            display_name: username === 'operator_alpha' ? 'Opérateur Marchand Alpha' : username,
            image_b64: b64
          })
        });
        const d = await res.json();
        if (res.ok && d.success) {
          fb.textContent = `✓ Votre visage a été mémorisé avec succès pour '${username}' ! Cliquez sur 'Analyser mon visage'.`;
          fb.style.color = "#34d399";
          currentLockoutSecs = 0;
          document.getElementById('lockout-countdown').style.display = 'none';
          document.getElementById('bio-cam-btn').disabled = false;
        } else {
          fb.textContent = "Erreur enrôlement : " + (d.error || d.message || "Visage non détecté");
          fb.style.color = "#f87171";
        }
      } catch (e) {
        fb.textContent = "Erreur : " + e.message;
        fb.style.color = "#f87171";
      }
      refreshBiometricHabilitations();
    }

    async function triggerBiometricFaceCheck() {
      const username = document.getElementById('bio-username-input').value.trim();
      const fb = document.getElementById('bio-feedback-msg');
      if (!username) {
        fb.textContent = 'Veuillez saisir un identifiant.';
        fb.style.color = '#f87171';
        return;
      }
      fb.textContent = '📸 Déclenchement de la caméra de votre PC portable et analyse du visage par l\'IA...';
      fb.style.color = '#38bdf8';
      document.getElementById('bio-cam-btn').disabled = true;

      const b64 = captureLaptopVideoFrame();

      try {
        const res = await fetch('/live/v1/bio-identify', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({username: username, use_camera: true, image_b64: b64})
        });
        const data = await res.json();
        if (res.ok && data.face_verified) {
          bioFaceVerified = true;
          fb.textContent = `✓ Visage reconnu (similarité ${((data.similarity_score || 0.85)*100).toFixed(1)}%). LED : Vert clignotant. Mot de passe débloqué !`;
          fb.style.color = '#34d399';
          document.getElementById('bio-password-input').disabled = false;
          document.getElementById('bio-password-input').style.background = '#020617';
          document.getElementById('bio-password-input').style.color = '#fff';
          document.getElementById('bio-login-btn').disabled = false;
          updateEspLedVisual('GREEN_BLINK');
        } else {
          bioFaceVerified = false;
          updateEspLedVisual('RED_SOLID_30S');
          if (data.locked) {
            currentLockoutSecs = data.locked_seconds_remaining || 300;
            document.getElementById('lockout-secs').textContent = currentLockoutSecs;
            document.getElementById('lockout-countdown').style.display = 'inline';
            fb.textContent = `✗ ${data.message} LED : Rouge fixe 30s.`;
            fb.style.color = '#ef4444';
          } else {
            fb.textContent = `✗ ${data.message} Nom d'utilisateur réinitialisé. LED : Rouge fixe 30s.`;
            fb.style.color = '#fbbf24';
            document.getElementById('bio-username-input').value = '';
            document.getElementById('bio-cam-btn').disabled = false;
          }
        }
      } catch (err) {
        fb.textContent = 'Erreur biométrique : ' + err.message;
        fb.style.color = '#f87171';
        document.getElementById('bio-cam-btn').disabled = false;
      }
      refreshBiometricHabilitations();
    }

    async function validatePasswordAndLogin() {
      const username = document.getElementById('bio-username-input').value.trim();
      const password = document.getElementById('bio-password-input').value;
      const fb = document.getElementById('bio-feedback-msg');

      try {
        const res = await fetch('/live/v1/bio-login', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({username: username, password: password})
        });
        const data = await res.json();
        if (res.ok && data.success) {
          updateEspLedVisual('GREEN_SOLID_30S');
          fb.textContent = '✓ Authentification réussie ! LED : Vert fixe 30s. Accès Back-office autorisé.';
          fb.style.color = '#34d399';
        } else {
          updateEspLedVisual('RED_BLINK_10X');
          fb.textContent = '✗ Mot de passe incorrect ! LED : Rouge clignote 10 fois. Recommencez le cycle.';
          fb.style.color = '#ef4444';
          bioFaceVerified = false;
          document.getElementById('bio-password-input').disabled = true;
          document.getElementById('bio-login-btn').disabled = true;
          document.getElementById('bio-cam-btn').disabled = false;
        }
      } catch (err) {
        fb.textContent = 'Erreur : ' + err.message;
      }
      refreshBiometricHabilitations();
    }

    async function testLedState(state) {
      await fetch('/live/v1/bio-led-test', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({state: state})
      });
      updateEspLedVisual(state);
    }

    async function resetOperatorLockout(u) {
      await fetch('/live/v1/bio-reset', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({username: u})
      });
      currentLockoutSecs = 0;
      document.getElementById('lockout-countdown').style.display = 'none';
      document.getElementById('bio-cam-btn').disabled = false;
      refreshBiometricHabilitations();
    }

    async function refreshBiometricHabilitations() {
      try {
        const r = await fetch('/live/v1/summary');
        const s = await r.json();
        const bio = s.biometrics || {};
        if (bio.esp_hardware) {
          updateEspLedVisual(bio.esp_hardware.current_state, bio.esp_hardware.port);
        }
        const tbody = document.getElementById('bio-habilitations-table');
        if (tbody && bio.habilitations) {
          tbody.innerHTML = bio.habilitations.map(h => `
            <tr>
              <td><strong>${h.display_name}</strong></td>
              <td class="mono">${h.username}</td>
              <td>${h.role}</td>
              <td><span style="color:${h.is_locked ? '#f87171' : '#34d399'};font-weight:700">${h.is_locked ? 'BLOQUÉ (' + h.lockout_seconds_remaining + 's)' : h.status}</span></td>
              <td>${h.is_locked ? `<button class="amber" style="padding:2px 6px;font-size:0.7rem;margin:0;" onclick="resetOperatorLockout('${h.username}')">Débloquer</button>` : '—'}</td>
            </tr>
          `).join('');
        }
      } catch (e) {}
    }

    setInterval(refreshState, 1200);
    refreshState();
  